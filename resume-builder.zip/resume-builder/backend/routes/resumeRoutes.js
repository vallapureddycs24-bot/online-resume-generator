const express = require("express");
const router = express.Router();
const auth = require("../middleware/authMiddleware");
const Resume = require("../models/Resume");

// SAVE RESUME
router.post("/", auth, async (req, res) => {
  try {
    const resume = new Resume({
      ...req.body,
      user: req.user.id
    });

    await resume.save();
    res.json({ msg: "Resume saved" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server error" });
  }
});

module.exports = router;
