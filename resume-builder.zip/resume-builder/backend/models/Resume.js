const mongoose = require("mongoose");

const ResumeSchema = new mongoose.Schema({
  user: mongoose.Schema.Types.ObjectId,
  name: String,
  email: String,
  phone: String,
  summary: String,
  department: String,
  photo: String,
  skills: [String],
  education: String,
  experience: String,
  certifications: String
});

module.exports = mongoose.model("Resume", ResumeSchema);
